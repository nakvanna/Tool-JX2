Follow by steps:
 - Extract JX2Auto.zip
 - Run JX2Update to get JX2Auto newest version
 - Run JXAuto to use this tool
